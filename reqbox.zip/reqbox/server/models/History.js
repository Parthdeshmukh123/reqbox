const mongoose = require('mongoose');
const { Mixed, ObjectId } = mongoose.Schema.Types;
module.exports = mongoose.model('History', new mongoose.Schema({
  environmentId: { type: ObjectId, ref: 'Environment' },
  method: String, url: String, headers: Mixed, params: Mixed, body: Mixed, auth: Mixed,
  status: Number, durationMs: Number, sizeBytes: Number,
}, { timestamps: true }));
