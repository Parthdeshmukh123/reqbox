const mongoose = require('mongoose');
module.exports = new mongoose.Schema(
  { key: String, value: String, enabled: { type: Boolean, default: true } },
  { _id: false }
);
