const mongoose = require('mongoose');
const KeyValue = require('./KeyValue');
module.exports = mongoose.model('Environment', new mongoose.Schema(
  { name: { type: String, required: true }, variables: [KeyValue] },
  { timestamps: true }
));
