const mongoose = require('mongoose');
const KeyValue = require('./KeyValue');
const SavedRequestSchema = new mongoose.Schema({
  collectionId: { type: mongoose.Schema.Types.ObjectId, ref: 'Collection', required: true },
  name: { type: String, required: true },
  method: { type: String, default: 'GET', enum: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] },
  url: { type: String, default: '' },
  headers: [KeyValue],
  params: [KeyValue],
  body: { mode: { type: String, default: 'none' }, content: String },
  auth: {
    scheme: { type: String, default: 'none' },
    token: String, username: String, password: String,
    keyName: String, keyValue: String,
    addTo: { type: String, default: 'header' },
  },
}, { timestamps: true });
module.exports = mongoose.model('SavedRequest', SavedRequestSchema);
