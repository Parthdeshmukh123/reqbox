require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json({ limit: '5mb' }));
app.get('/', (req, res) => res.json({ app: 'reqbox', status: 'ok' }));
app.use('/api/proxy', require('./routes/proxy'));
app.use('/api/collections', require('./routes/collections'));
app.use('/api/environments', require('./routes/environments'));
app.use('/api/history', require('./routes/history'));
app.use('/api/data', require('./routes/transfer'));
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    const port = process.env.PORT || 5000;
    app.listen(port, () => console.log(`Reqbox API on port ${port}`));
  })
  .catch((err) => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
