const express = require('express');
const Environment = require('../models/Environment');
const router = express.Router();
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(400).json({ message: e.message }));

router.get('/', wrap(async (req, res) => res.json(await Environment.find().sort('createdAt'))));
router.post('/', wrap(async (req, res) => res.json(await Environment.create(req.body))));
router.put('/:id', wrap(async (req, res) =>
  res.json(await Environment.findByIdAndUpdate(req.params.id, req.body, { new: true }))));
router.delete('/:id', wrap(async (req, res) => {
  await Environment.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
}));
module.exports = router;
