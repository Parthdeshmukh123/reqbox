const express = require('express');
const Collection = require('../models/Collection');
const SavedRequest = require('../models/SavedRequest');
const router = express.Router();
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(400).json({ message: e.message }));

router.get('/', wrap(async (req, res) => {
  const [cols, reqs] = await Promise.all([Collection.find().sort('createdAt').lean(), SavedRequest.find().lean()]);
  res.json(cols.map((c) => ({ ...c, requests: reqs.filter((r) => String(r.collectionId) === String(c._id)) })));
}));
router.post('/', wrap(async (req, res) => res.json(await Collection.create(req.body))));
router.delete('/requests/:rid', wrap(async (req, res) => {
  await SavedRequest.findByIdAndDelete(req.params.rid);
  res.json({ ok: true });
}));
router.delete('/:id', wrap(async (req, res) => {
  await SavedRequest.deleteMany({ collectionId: req.params.id });
  await Collection.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
}));
router.post('/:id/requests', wrap(async (req, res) =>
  res.json(await SavedRequest.create({ ...req.body, collectionId: req.params.id }))));
module.exports = router;
