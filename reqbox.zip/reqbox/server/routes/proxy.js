const express = require('express');
const axios = require('axios');
const History = require('../models/History');
const router = express.Router();

// Block localhost / private network targets (set ALLOW_PRIVATE=true in .env to allow them)
const PRIVATE = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.0\.0\.0|\[?::1)/i;

router.post('/', async (req, res) => {
  const { method = 'GET', url, headers = {}, params = {}, body, environmentId } = req.body;
  if (!/^https?:\/\//i.test(url || '')) {
    return res.status(400).json({ message: 'URL must start with http:// or https://' });
  }
  let hostname;
  try { hostname = new URL(url).hostname; }
  catch { return res.status(400).json({ message: 'Invalid URL' }); }
  if (process.env.ALLOW_PRIVATE !== 'true' && PRIVATE.test(hostname)) {
    return res.status(403).json({ message: 'Private addresses are blocked. Set ALLOW_PRIVATE=true to test local APIs.' });
  }
  const started = Date.now();
  try {
    const response = await axios({
      method, url, headers, params, data: body,
      timeout: 30000,
      validateStatus: () => true,
      responseType: 'text',
      transformResponse: (raw) => raw,
    });
    const durationMs = Date.now() - started;
    const raw = response.data || '';
    const sizeBytes = Buffer.byteLength(raw, 'utf8');
    await History.create({
      method, url, headers, params, body,
      environmentId: environmentId || undefined,
      status: response.status, durationMs, sizeBytes,
    });
    res.json({ status: response.status, statusText: response.statusText,
      headers: response.headers, body: raw, durationMs, sizeBytes });
  } catch (err) {
    res.status(502).json({ error: err.code || 'REQUEST_FAILED', message: err.message });
  }
});
module.exports = router;
