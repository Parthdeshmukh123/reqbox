const express = require('express');
const Collection = require('../models/Collection');
const SavedRequest = require('../models/SavedRequest');
const Environment = require('../models/Environment');
const router = express.Router();

router.get('/export', async (req, res) => {
  const [cols, reqs, envs] = await Promise.all([
    Collection.find().lean(), SavedRequest.find().lean(), Environment.find().lean(),
  ]);
  res.setHeader('Content-Disposition', 'attachment; filename="reqbox-export.json"');
  res.json({
    app: 'reqbox', version: 1, exportedAt: new Date().toISOString(),
    collections: cols.map((c) => ({ ...c, requests: reqs.filter((r) => String(r.collectionId) === String(c._id)) })),
    environments: envs,
  });
});

router.post('/import', async (req, res) => {
  const { app, collections = [], environments = [] } = req.body;
  if (app !== 'reqbox') return res.status(400).json({ message: 'Not a Reqbox export file' });
  for (const c of collections) {
    const col = await Collection.create({ name: c.name, description: c.description });
    if (c.requests?.length) {
      await SavedRequest.insertMany(c.requests.map(({ _id, collectionId, ...r }) => ({ ...r, collectionId: col._id })));
    }
  }
  if (environments.length) await Environment.insertMany(environments.map(({ _id, ...e }) => e));
  res.json({ imported: { collections: collections.length, environments: environments.length } });
});
module.exports = router;
