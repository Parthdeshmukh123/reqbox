const express = require('express');
const History = require('../models/History');
const router = express.Router();
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(400).json({ message: e.message }));

router.get('/', wrap(async (req, res) => res.json(await History.find().sort('-createdAt').limit(50))));
router.delete('/', wrap(async (req, res) => { await History.deleteMany({}); res.json({ ok: true }); }));
module.exports = router;
