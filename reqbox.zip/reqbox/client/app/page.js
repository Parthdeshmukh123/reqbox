'use client';
import { useEffect, useRef, useState } from 'react';
import { api, API_BASE } from '../lib/api';
import { buildPayload } from '../lib/buildPayload';
import { resolveRequest } from '../lib/resolveVariables';

const METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
const emptyRow = () => ({ key: '', value: '', enabled: true });
let counter = 1;
const newTab = (over = {}) => ({
  id: 't' + counter++, name: 'New Request', method: 'GET', url: '',
  headers: [emptyRow()], params: [emptyRow()],
  body: { mode: 'none', content: '' },
  auth: { scheme: 'none', token: '', username: '', password: '', keyName: '', keyValue: '', addTo: 'header' },
  section: 'params', res: null, loading: false, error: '', ...over,
});

function KVEditor({ rows, onChange }) {
  const set = (i, patch) => onChange(rows.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  return (
    <div>
      {rows.map((r, i) => (
        <div className="row" key={i}>
          <input type="checkbox" checked={r.enabled} onChange={(e) => set(i, { enabled: e.target.checked })} />
          <input placeholder="Key" value={r.key} onChange={(e) => set(i, { key: e.target.value })} />
          <input placeholder="Value" value={r.value} onChange={(e) => set(i, { value: e.target.value })} />
          <button className="link" onClick={() => onChange(rows.filter((_, j) => j !== i))}>✕</button>
        </div>
      ))}
      <button onClick={() => onChange([...rows, emptyRow()])}>+ Add row</button>
    </div>
  );
}

function prettyBody(res) {
  try { return JSON.stringify(JSON.parse(res.body), null, 2); } catch { return res.body; }
}

export default function Home() {
  const [tabs, setTabs] = useState([newTab()]);
  const [activeId, setActiveId] = useState(tabs[0].id);
  const [envs, setEnvs] = useState([]);
  const [envId, setEnvId] = useState('');
  const [cols, setCols] = useState([]);
  const [hist, setHist] = useState([]);
  const [side, setSide] = useState('collections');
  const [resView, setResView] = useState('body');
  const [toast, setToast] = useState('');
  const fileRef = useRef(null);

  const tab = tabs.find((t) => t.id === activeId) || tabs[0];
  const upd = (id, patch) => setTabs((ts) => ts.map((t) => (t.id === id ? { ...t, ...patch } : t)));
  const flash = (m) => { setToast(m); setTimeout(() => setToast(''), 2500); };

  const loadCols = () => api('/api/collections').then(setCols).catch((e) => flash(e.message));
  const loadEnvs = () => api('/api/environments').then(setEnvs).catch((e) => flash(e.message));
  const loadHist = () => api('/api/history').then(setHist).catch(() => {});
  useEffect(() => { loadCols(); loadEnvs(); loadHist(); }, []);

  function addTab(over) { const t = newTab(over); setTabs((ts) => [...ts, t]); setActiveId(t.id); }
  function closeTab(id) {
    if (tabs.length === 1) { const t = newTab(); setTabs([t]); setActiveId(t.id); return; }
    const rest = tabs.filter((t) => t.id !== id);
    setTabs(rest);
    if (id === activeId) setActiveId(rest[rest.length - 1].id);
  }

  async function send() {
    const t = tab;
    upd(t.id, { loading: true, error: '', res: null });
    try {
      const env = envs.find((e) => e._id === envId);
      const payload = { ...buildPayload(resolveRequest(t, env?.variables)), environmentId: env?._id };
      const res = await api('/api/proxy', { method: 'POST', body: payload });
      upd(t.id, { res, loading: false }); loadHist();
    } catch (e) { upd(t.id, { error: e.message, loading: false }); }
  }

  async function save() {
    try {
      let cid = cols[0]?._id;
      if (!cid) { cid = (await api('/api/collections', { method: 'POST', body: { name: 'My collection' } }))._id; }
      const name = window.prompt('Request name', tab.name) || tab.name;
      const { id, res, loading, error, section, ...r } = tab;
      await api(`/api/collections/${cid}/requests`, { method: 'POST', body: { ...r, name } });
      upd(tab.id, { name }); loadCols(); flash('Request saved');
    } catch (e) { flash(e.message); }
  }

  async function newCollection() {
    const name = window.prompt('Collection name');
    if (!name) return;
    try { await api('/api/collections', { method: 'POST', body: { name } }); loadCols(); } catch (e) { flash(e.message); }
  }
  async function delCollection(id) {
    if (!window.confirm('Delete this collection and its requests?')) return;
    await api(`/api/collections/${id}`, { method: 'DELETE' }); loadCols();
  }
  async function delRequest(id) { await api(`/api/collections/requests/${id}`, { method: 'DELETE' }); loadCols(); }
  function openSaved(r) {
    addTab({ name: r.name, method: r.method, url: r.url, headers: r.headers?.length ? r.headers : [emptyRow()],
      params: r.params?.length ? r.params : [emptyRow()], body: r.body || { mode: 'none', content: '' },
      auth: { ...newTab().auth, ...(r.auth || {}) } });
  }
  function openHistory(h) {
    const toRows = (o) => { const rows = Object.entries(o || {}).map(([key, value]) => ({ key, value: String(value), enabled: true })); return rows.length ? rows : [emptyRow()]; };
    const isObj = h.body && typeof h.body === 'object';
    addTab({ name: h.method + ' ' + h.url.slice(0, 24), method: h.method, url: h.url, headers: toRows(h.headers), params: toRows(h.params),
      body: h.body ? { mode: isObj ? 'json' : 'raw', content: isObj ? JSON.stringify(h.body, null, 2) : String(h.body) } : { mode: 'none', content: '' } });
  }
  async function clearHistory() { await api('/api/history', { method: 'DELETE' }); loadHist(); }

  // environments
  async function newEnv() {
    const name = window.prompt('Environment name (e.g. Development)');
    if (!name) return;
    const e = await api('/api/environments', { method: 'POST', body: { name, variables: [emptyRow()] } });
    await loadEnvs(); setEnvId(e._id);
  }
  const curEnv = envs.find((e) => e._id === envId);
  const setEnvVars = (variables) => setEnvs((es) => es.map((e) => (e._id === envId ? { ...e, variables } : e)));
  async function saveEnv() {
    await api(`/api/environments/${envId}`, { method: 'PUT', body: { name: curEnv.name, variables: curEnv.variables } });
    flash('Environment saved');
  }
  async function delEnv() {
    if (!window.confirm('Delete this environment?')) return;
    await api(`/api/environments/${envId}`, { method: 'DELETE' }); setEnvId(''); loadEnvs();
  }

  // import / export
  async function importFile(e) {
    const f = e.target.files[0]; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      const r = await api('/api/data/import', { method: 'POST', body: data });
      flash(`Imported ${r.imported.collections} collections, ${r.imported.environments} environments`);
      loadCols(); loadEnvs();
    } catch (err) { flash(err.message); }
    e.target.value = '';
  }

  const res = tab.res;
  const sc = res ? (res.status < 300 ? 'var(--ok)' : res.status < 400 ? 'var(--warn)' : 'var(--err)') : '';

  return (
    <div className="app">
      <div className="top">
        <span className="logo">⚡ Reqbox</span>
        <select value={envId} onChange={(e) => setEnvId(e.target.value)}>
          <option value="">No environment</option>
          {envs.map((e) => <option key={e._id} value={e._id}>{e.name}</option>)}
        </select>
        <button onClick={() => { setSide('env'); }}>Environments</button>
        <a href={`${API_BASE}/api/data/export`}><button>Export</button></a>
        <button onClick={() => fileRef.current.click()}>Import</button>
        <input ref={fileRef} type="file" accept=".json" onChange={importFile} style={{ display: 'none' }} />
      </div>

      <div className="main">
        <div className="side">
          <div className="sub">
            {['collections', 'history', 'env'].map((s) => (
              <button key={s} className={side === s ? 'on' : ''} onClick={() => setSide(s)}>{s === 'env' ? 'Environments' : s[0].toUpperCase() + s.slice(1)}</button>
            ))}
          </div>

          {side === 'collections' && (<>
            <button onClick={newCollection}>+ New collection</button>
            {cols.map((c) => (
              <div key={c._id}>
                <h4>{c.name} <button className="link" onClick={() => delCollection(c._id)}>delete</button></h4>
                {c.requests.map((r) => (
                  <div className="item" key={r._id} onClick={() => openSaved(r)}>
                    <span><span className="badge">{r.method}</span>{r.name}</span>
                    <button className="link" onClick={(e) => { e.stopPropagation(); delRequest(r._id); }}>✕</button>
                  </div>
                ))}
                {!c.requests.length && <div style={{ color: 'var(--muted)' }}>Empty</div>}
              </div>
            ))}
          </>)}

          {side === 'history' && (<>
            <button onClick={clearHistory}>Clear history</button>
            {hist.map((h) => (
              <div className="item" key={h._id} onClick={() => openHistory(h)}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}><span className="badge">{h.method}</span>{h.url}</span>
                <span className="pill">{h.status}</span>
              </div>
            ))}
            {!hist.length && <div style={{ color: 'var(--muted)', marginTop: 8 }}>No requests yet</div>}
          </>)}

          {side === 'env' && (<>
            <button onClick={newEnv}>+ New environment</button>
            {curEnv ? (<>
              <h4>{curEnv.name} variables</h4>
              <KVEditor rows={curEnv.variables} onChange={setEnvVars} />
              <div className="row" style={{ marginTop: 8 }}>
                <button className="primary" onClick={saveEnv}>Save</button>
                <button onClick={delEnv}>Delete</button>
              </div>
              <div style={{ color: 'var(--muted)' }}>Use as {'{{name}}'} in URL, headers, params, body and auth.</div>
            </>) : <div style={{ color: 'var(--muted)', marginTop: 8 }}>Select or create an environment.</div>}
          </>)}
        </div>

        <div className="work">
          <div className="tabs">
            {tabs.map((t) => (
              <div key={t.id} className={'tab' + (t.id === activeId ? ' active' : '')} onClick={() => setActiveId(t.id)}>
                <span className="badge">{t.method}</span>{t.name} <span onClick={(e) => { e.stopPropagation(); closeTab(t.id); }}>✕</span>
              </div>
            ))}
            <button onClick={() => addTab()}>+</button>
          </div>

          <div className="bar">
            <select value={tab.method} onChange={(e) => upd(tab.id, { method: e.target.value })}>
              {METHODS.map((m) => <option key={m}>{m}</option>)}
            </select>
            <input placeholder="https://api.example.com/users  or  {{baseUrl}}/users" value={tab.url} onChange={(e) => upd(tab.id, { url: e.target.value })} />
            <button className="primary" onClick={send} disabled={tab.loading}>{tab.loading ? '...' : 'Send'}</button>
            <button onClick={save}>Save</button>
          </div>

          <div className="sub">
            {['params', 'headers', 'body', 'auth'].map((s) => (
              <button key={s} className={tab.section === s ? 'on' : ''} onClick={() => upd(tab.id, { section: s })}>{s[0].toUpperCase() + s.slice(1)}</button>
            ))}
          </div>

          {tab.section === 'params' && <KVEditor rows={tab.params} onChange={(params) => upd(tab.id, { params })} />}
          {tab.section === 'headers' && <KVEditor rows={tab.headers} onChange={(headers) => upd(tab.id, { headers })} />}
          {tab.section === 'body' && (<>
            <div className="row">
              {['none', 'json', 'raw'].map((m) => (
                <label key={m}><input type="radio" checked={tab.body.mode === m} onChange={() => upd(tab.id, { body: { ...tab.body, mode: m } })} /> {m}</label>
              ))}
            </div>
            {tab.body.mode !== 'none' && <textarea placeholder={tab.body.mode === 'json' ? '{ "name": "Parth" }' : 'Raw text'} value={tab.body.content} onChange={(e) => upd(tab.id, { body: { ...tab.body, content: e.target.value } })} />}
          </>)}
          {tab.section === 'auth' && (<>
            <select value={tab.auth.scheme} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, scheme: e.target.value } })}>
              <option value="none">No Auth</option><option value="bearer">Bearer Token</option>
              <option value="basic">Basic Auth</option><option value="apikey">API Key</option>
            </select>
            <div style={{ marginTop: 8 }}>
              {tab.auth.scheme === 'bearer' && <input style={{ width: '100%' }} placeholder="Token" value={tab.auth.token} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, token: e.target.value } })} />}
              {tab.auth.scheme === 'basic' && (<div className="row">
                <input placeholder="Username" value={tab.auth.username} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, username: e.target.value } })} />
                <input type="password" placeholder="Password" value={tab.auth.password} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, password: e.target.value } })} />
              </div>)}
              {tab.auth.scheme === 'apikey' && (<div className="row">
                <input placeholder="Key name" value={tab.auth.keyName} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, keyName: e.target.value } })} />
                <input placeholder="Key value" value={tab.auth.keyValue} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, keyValue: e.target.value } })} />
                <select value={tab.auth.addTo} onChange={(e) => upd(tab.id, { auth: { ...tab.auth, addTo: e.target.value } })}>
                  <option value="header">Header</option><option value="query">Query</option>
                </select>
              </div>)}
            </div>
          </>)}

          <h4>Response</h4>
          {tab.error && <div className="err">{tab.error}</div>}
          {tab.loading && <div>Sending...</div>}
          {res && (<>
            <div className="stat">
              <span className="pill" style={{ color: sc, borderColor: sc }}>{res.status} {res.statusText}</span>
              <span className="pill">{res.durationMs} ms</span>
              <span className="pill">{res.sizeBytes} B</span>
            </div>
            <div className="sub">
              <button className={resView === 'body' ? 'on' : ''} onClick={() => setResView('body')}>Body</button>
              <button className={resView === 'headers' ? 'on' : ''} onClick={() => setResView('headers')}>Headers</button>
            </div>
            <pre>{resView === 'body' ? prettyBody(res) : Object.entries(res.headers || {}).map(([k, v]) => `${k}: ${v}`).join('\n')}</pre>
          </>)}
          {!res && !tab.loading && !tab.error && <div style={{ color: 'var(--muted)' }}>Enter a URL and press Send.</div>}
        </div>
      </div>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
