# Reqbox - A Browser-Based API Testing Tool

Next.js frontend + Express/Axios proxy backend + MongoDB Atlas (Mongoose).

## Run locally (or in GitHub Codespaces)
1. `npm run install:all`
2. `cp server/.env.example server/.env` and put your MongoDB Atlas URI in `MONGODB_URI`
3. `cp client/.env.example client/.env.local`
4. Terminal 1: `npm run server`   (API on :5000)
5. Terminal 2: `npm run client`   (UI on :3000)

## Deploy
- Backend -> Render (root dir `server`, build `npm install`, start `node server.js`, env: MONGODB_URI, CLIENT_URL=<vercel url>)
- Frontend -> Vercel (root dir `client`, env: NEXT_PUBLIC_API_URL=<render url>)
